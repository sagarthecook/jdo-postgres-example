![image](https://github.com/user-attachments/assets/095413c7-723b-44a7-b29e-bd6e539c9281)

![image](https://github.com/user-attachments/assets/c1c6ac4d-0e99-4d30-81f5-b79d5805feb4)

![image](https://github.com/user-attachments/assets/8b9f7217-bdad-4249-b8d9-0a4e1e2df407)


![image](https://github.com/user-attachments/assets/d9389d38-57ef-454d-8dc0-49c3328475cf)


