export interface IMessageMenu {
    id:string;
    name:string;
}
