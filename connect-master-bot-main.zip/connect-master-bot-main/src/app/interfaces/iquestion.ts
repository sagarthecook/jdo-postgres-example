export interface IQuestion {
    questionId:string;
    question:string
    dataType:string
    uiControlType:string
    answer:string
    values: string[];
}
